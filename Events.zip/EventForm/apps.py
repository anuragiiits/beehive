from django.apps import AppConfig


class EventformConfig(AppConfig):
    name = 'EventForm'
