from django.apps import AppConfig


class UserauthConfig(AppConfig):
    name = 'UserAuth'
